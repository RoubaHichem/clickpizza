package com.example.flutter_myapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity:  FlutterActivity() {
    // You do not need to override onCreate() in order to invoke
    // GeneratedPluginRegistrant. Flutter now does that on your behalf.

    // ...retain whatever custom code you had from before (if any).
}
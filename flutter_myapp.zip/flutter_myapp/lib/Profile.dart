
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_myapp/buy.dart';
import 'package:flutter_myapp/login.dart';
import 'package:flutter_myapp/pizza.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'Bottomappbar.dart';




class PROFILE extends StatelessWidget {
  String email;
  String nom;
  String numero;
  @override
  Widget build(BuildContext context) {
    return Scaffold(

         body: Stack(
          children: [
           Stack(
              children: [
                Positioned(
                    left: 170,
                    top: 100,
                  child: Text("Profile",style: TextStyle(fontSize: 25,fontWeight: FontWeight.bold),),),
                Positioned(
                  left: 330,
                  top: 80,
                  child: Container(
                    height: 65,
                    width: 70,
                    decoration: BoxDecoration(
                      color: Colors.red,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Icon(FontAwesomeIcons.user,color: Colors.white,),
                  ),),
                Positioned(
                  left: 20,
                  top: 80,
                  child: Container(
                      height: 65,
                      width: 70,
                      decoration: BoxDecoration(
                        color: Colors.red,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: IconButton(
                        icon: Icon(FontAwesomeIcons.angleLeft,color: Colors.white,),
                        onPressed: (){
                          Navigator.of(context).push(MaterialPageRoute(builder:(context)=>PIZZA()));
                        },
                      )
                  ),),
                Positioned(
                 left: 25,
                 top: 190,
                 child: Container(
                   height: 400,
                   width: 370,
                  child: Card(
                      color: Colors.red,
                   shadowColor: Colors.black,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15)
                      ),
                   elevation: 8,
                    child:FutureBuilder(
                      future: _fetch(),
                      builder: (context,snapshot){
                        if(snapshot.connectionState!=ConnectionState.done)
                          return Text("");
                        return Padding(
                          padding: const EdgeInsets.all(10),
                          child: Column(
                            children: [
                              Container(
                                height: 100,
                                width: 100,
                                decoration: BoxDecoration(
                                    image: DecorationImage(
                                      image: AssetImage('images/user2.png'),
                                    )
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(50),
                                child: Text("$nom",style: TextStyle(fontSize: 25,fontWeight:FontWeight.bold,color:Colors.white),),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text("Email : $email",style: TextStyle(fontSize: 20,color: Colors.white),),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text("Numéro de téléphone :$numero",style: TextStyle(fontSize: 20,color: Colors.white),),
                              ),
                            ],
                          )
                        );
                      },
                    )),
               ),
             ),
                Positioned(
                  left: 40,
                  top: 660,
                  child: Container(
                   child: SizedBox(
                     width: 350,
                     height: 55 ,
                     child: RaisedButton(
                       onPressed:(){
                         Navigator.of(context).push(MaterialPageRoute(builder:(context)=>HOME()));
                       },
                       splashColor: Colors.transparent,
                       highlightElevation: 20,
                       color: Colors.red,
                       shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(10))),
                       child :
                       Text('Déconnexion', style:
                       TextStyle(
                         fontSize: 20,
                         color: Colors.white,
                         fontWeight: FontWeight.bold,
                         fontFamily: 'Montserrat',
                       ),

                       ),
                  ),
                ),
                  ),
                  ),
              ],
            ),

          ],
         ),

      bottomNavigationBar: BottomBar(),
    );

  }

  _fetch() async {
    final firebaseUser = await FirebaseAuth.instance.currentUser();

    if (firebaseUser != null)
      await Firestore.instance
          .collection('users')
          .document(firebaseUser.uid)
          .get()
          .then((ds) {
            email = ds.data['email'];
            nom = ds.data['name'];
            numero =ds.data['phone'];
      }).catchError((e) {
        print(e);
      });
  }

}

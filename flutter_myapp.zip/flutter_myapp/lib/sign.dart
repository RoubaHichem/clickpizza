import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_myapp/pizza.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import 'Profile.dart';



class SIGN extends StatefulWidget {
  @override
  _SIGNState createState() => _SIGNState();
}

class _SIGNState extends State<SIGN> {

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  TextEditingController _emailController = TextEditingController();
  TextEditingController _passwordController = TextEditingController();
  TextEditingController _userController = TextEditingController();
  TextEditingController _phoneController = TextEditingController();
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  FirebaseUser user;
    String name;
    String id;
    String phone;
    final db = Firestore.instance;
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
          decoration: BoxDecoration(
              image: DecorationImage(
                  image: AssetImage('images/back1.jpg'),
                  fit: BoxFit.fill,
                  colorFilter: ColorFilter.mode(Colors.black26, BlendMode.darken)
              )
          ),
        ),
        Scaffold(
         key: _scaffoldKey,
          backgroundColor: Colors.transparent,
          body: SingleChildScrollView(
            child: Form(
              key: _formKey,
              child: Column(
                children: [
                  SizedBox(height: 150,),
                  Padding(
                    padding: const EdgeInsets.all(20),
                    child: Text("OneClickPizza",style: TextStyle(fontSize: 45,color: Colors.white),),
                  ),
                  SizedBox(height: 30,),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 15),
                    child: Container(
                      margin: EdgeInsets.symmetric(horizontal: 30),
                      height: 60,
                      width: 340,
                      decoration: BoxDecoration(
                        color : Colors.grey[500].withOpacity(0.5),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Center(
                        child: TextFormField(
                          controller: _userController,
                          decoration: InputDecoration(
                            border: InputBorder.none,
                            hintStyle: new TextStyle(color: Colors.white),
                            prefixIcon: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 20,),
                              child: Icon(FontAwesomeIcons.user,
                                size: 25,
                                color: Colors.white,),
                            ),
                            hintText: "Nom d'utilisateur",
                          ),
                          validator: (String val){
                            if (val.isEmpty){
                              return "S'il vous plaît entrez votre nom";
                            }
                            return null;
                          },
                          onChanged: (value) => setState(() {
                            name = value;
                          }),
                        ),
                      ),
                    ),
                  ),
                    Padding(
                    padding: const EdgeInsets.symmetric(vertical: 15),
                    child: Container(
                      margin: EdgeInsets.symmetric(horizontal: 30),
                      height: 60,
                      width: 340,
                      decoration: BoxDecoration(
                        color : Colors.grey[500].withOpacity(0.5),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Center(
                        child: TextFormField(
                          controller: _phoneController,
                          decoration: InputDecoration(
                            border: InputBorder.none,
                            hintStyle: new TextStyle(color: Colors.white),
                            prefixIcon: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 20,),
                              child: Icon(FontAwesomeIcons.phone,
                                size: 25,
                                color: Colors.white,),
                            ),
                            hintText: "Numéro de téléphone",
                          ),
                          validator: (String val){
                            if (val.isEmpty){
                              return "S'il vous plaît entrez votre Numéro de téléphone";
                            }
                            return null;
                          },
                          onChanged: (value) => setState(() {
                            phone = value;
                          }),
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 15),
                    child: Container(
                      margin: EdgeInsets.symmetric(horizontal: 30),
                      height: 60,
                      width: 340,
                      decoration: BoxDecoration(
                        color : Colors.grey[500].withOpacity(0.5),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Center(
                        child: TextFormField(
                          controller: _emailController,
                          decoration: InputDecoration(
                            border: InputBorder.none,
                            hintStyle: new TextStyle(color: Colors.white),
                            prefixIcon: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 20,),
                              child: Icon(FontAwesomeIcons.envelope,
                                size: 25,
                                color: Colors.white,),
                            ),
                            hintText: "Email",
                          ),
                          validator: (String val){
                            if (val.isEmpty){
                              return "S'il vous plaît entrez votre email";
                            }
                            return null;
                          },
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 15),
                    child: Container(
                      margin: EdgeInsets.symmetric(horizontal: 10),
                      height: 60,
                      width: 340,
                      decoration: BoxDecoration(
                        color : Colors.grey[500].withOpacity(0.5),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child:
                      Center(
                        child: TextFormField(
                          controller: _passwordController,
                          decoration: InputDecoration(
                            border: InputBorder.none,
                            hintStyle: new TextStyle(color: Colors.white),
                            prefixIcon: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 10,),
                              child: Icon(FontAwesomeIcons.lock,
                                size: 25,
                                color: Colors.white,),
                            ),
                            hintText: "Mot de passe",
                          ),
                          obscureText: true,
                          validator: (String val){
                            if(val.isEmpty){
                              return "S'il vous plaît entrez votre  Mot de passe";
                            }
                            return null;
                          },
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 15),
                    child: Container(
                      child: SizedBox(
                        width: 340,
                        height: 50,
                        // ignore: deprecated_member_use
                        child: RaisedButton(
                          onPressed: () async {
                            if(_formKey.currentState.validate()){
                              await _registerAccount();
                            }
                            },
                          splashColor: Colors.transparent,
                          elevation: 50,
                          highlightElevation: 30,
                          color:  Colors.redAccent,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(10))),
                          child: Text("S'inscrire",style: TextStyle(fontSize: 20,color: Colors.white),),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 10,),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 15),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Text("Vous avez un compte ? ",style: TextStyle(fontSize: 20,fontWeight: FontWeight.w400,color: Colors.white),),
                        GestureDetector(
                            onTap: (){ Navigator.of(context).pushNamed('/login');},
                            child:
                            Text("Se connecter",style: TextStyle(fontSize: 20,color:  Colors.redAccent, decoration: TextDecoration.underline,),))
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        )
      ],
    );
  }
  void _registerAccount() async {
    try {
      final user = (await _auth.createUserWithEmailAndPassword(
          email: _emailController.text, password: _passwordController.text,))
          .user;
      if (user != null) {
        if (!user.isEmailVerified) {
          await user.sendEmailVerification();
        }
        final firebaseUser = await FirebaseAuth.instance.currentUser();
        Firestore.instance
            .collection('users')
            .document(firebaseUser.uid)
            .setData({'email':user.email,'name':'$name','phone':'$phone'})
            .then((value) => Navigator.push(
            context, MaterialPageRoute(builder:(context)=>PIZZA())))
            .catchError((e){
          print(e);
        });
      }
    }catch(e){
    // ignore: deprecated_member_use
    _scaffoldKey.currentState.showSnackBar(SnackBar(content: Text("Ce compte existe déjà, essayez de vous connecter")));
    print(e.toString());
    }
  }
}

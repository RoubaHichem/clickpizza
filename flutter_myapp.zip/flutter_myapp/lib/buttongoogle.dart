import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';



class buttonMedia extends StatelessWidget {

  final Function press;
  final Color color, textColor;
  const buttonMedia({
    Key key,
    this.press,
    this.color = Colors.transparent,
    this.textColor = Colors.white,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Container(
      decoration: BoxDecoration(
          border: Border.all(
            width: 2,
            color: Colors.transparent,
          ),
          shape: BoxShape.circle),
      child: ClipRRect(
        child: FlatButton(
          onPressed: press,
          child: Icon(
            FontAwesomeIcons.google,
            color: Colors.white,
            size: 30,
          ),
        ),
      ),
    );
  }
}
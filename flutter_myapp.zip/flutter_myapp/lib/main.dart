

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_myapp/Profile.dart';
import 'package:flutter_myapp/login.dart';
import 'package:flutter_myapp/pizza.dart';
import 'package:flutter_myapp/sign.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';

void main() => runApp(MyApp());


class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(

      routes: {
       '/login' : (context)=> HOME(),
        '/pizza' : (context)=> PIZZA(),
        '/sign' : (context)=>SIGN(),
        '/Profile' : (context)=>PROFILE(),
      },
      home: SplachScreen(),
    );
  }

}
class SplachScreen extends StatefulWidget {
  @override
  _SplachScreenState createState() => _SplachScreenState();
}

class _SplachScreenState extends State<SplachScreen> {
  @override
  void initState() {
    super.initState();
    Timer(
        Duration(seconds: 8),
            () => Navigator.push(
            context, MaterialPageRoute(builder: (context) =>HOME())));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          Image.asset(
              'images/logo.png'),
          SpinKitFadingCube(
            color: Colors.red,
            size: 30,
          ),
        ],
      ),
    );
  }
}




import 'package:flutter/material.dart';
import 'package:flutter_myapp/Auth.dart';
import 'package:flutter_myapp/pizza.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'bottomfacebook.dart';
import 'buttongoogle.dart';
import 'food.dart';

class HOME extends StatefulWidget {

  @override
  _HOMEState createState() => _HOMEState();
}

class _HOMEState extends State<HOME> {
  FirebaseUser user;
  FirebaseAuth _auth = FirebaseAuth.instance;
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final GlobalKey<FormState> _formkey = GlobalKey<FormState>();
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
     return Stack(
       children: [
         Container(
           decoration: BoxDecoration(
               image: DecorationImage(
                 image: AssetImage('images/back1.jpg'),
                 fit: BoxFit.fill,
                 colorFilter: ColorFilter.mode(Colors.black26, BlendMode.darken)
               )
           ),
         ),
         Scaffold(
           backgroundColor: Colors.transparent,
           key: _scaffoldKey,
           body: SingleChildScrollView(
             child: Form(
               key: _formkey,
               child: Column(
                 children: [
                   SizedBox(height: 200,),
                   Container(
                     child: Column(
                       children: [
                         Padding(
                           padding: const EdgeInsets.all(20),
                           child: Text("OneClickPizza",style: TextStyle(fontSize: 45,color: Colors.white),),
                         ),
                         SizedBox(height: 50,),
                         Padding(
                           padding: const EdgeInsets.symmetric(vertical: 15),
                           child: Container(
                             margin: EdgeInsets.symmetric(horizontal: 10),
                             height: 60,
                             width: 340,
                             decoration: BoxDecoration(
                               color : Colors.grey[400].withOpacity(0.5),
                               borderRadius: BorderRadius.circular(10),
                             ),
                             child: Center(
                               child: TextFormField(
                                 controller: _emailController,
                                 decoration: InputDecoration(
                                   border: InputBorder.none,
                                   hintStyle: new TextStyle(color: Colors.white),
                                   prefixIcon: Padding(
                                     padding: const EdgeInsets.symmetric(horizontal: 20,),
                                     child: Icon(FontAwesomeIcons.envelope,
                                       size: 25,
                                       color: Colors.white,),
                                   ),
                                   hintText: "Email",
                                 ),
                                 autocorrect: false,
                                 keyboardType: TextInputType.emailAddress,
                                 textInputAction: TextInputAction.next,
                                 validator: (String val){
                                   if(val.isEmpty){
                                     return "S'il vous plaît entrez votre  email";
                                   }
                                   return null;
                                 },
                               ),
                             ),
                           ),
                         ),
                         Padding(
                           padding: const EdgeInsets.symmetric(vertical: 15),
                           child: Container(
                             margin: EdgeInsets.symmetric(horizontal: 10),
                             height: 60,
                             width: 340,
                             decoration: BoxDecoration(
                               color : Colors.grey[400].withOpacity(0.5),
                               borderRadius: BorderRadius.circular(10),
                             ),
                             child: Center(
                               child: TextFormField(
                                 controller: _passwordController,
                                 decoration: InputDecoration(
                                   border: InputBorder.none,
                                   hintStyle: new TextStyle(color: Colors.white),
                                   prefixIcon: Padding(
                                     padding: const EdgeInsets.symmetric(horizontal: 20,),
                                     child: Icon(FontAwesomeIcons.lock,
                                       size: 25,
                                       color: Colors.white,),
                                   ),
                                   hintText: "Mot de passe",
                                 ),
                                 obscureText: true,
                                 textInputAction: TextInputAction.done,
                                 validator: (String val){
                                   if(val.isEmpty){
                                     return "S'il vous plaît entrez votre Mot de passe ";
                                   }
                                   return null;
                                 },
                               ),
                             ),
                           ),
                         ),
                       ],
                     ),
                   ),
                   SizedBox(height: 15,),
                   Container(
                     child: Column(
                       children: [
                         Container(
                           child:  SizedBox(
                             width: 340,
                             height: 50 ,
                             // ignore: deprecated_member_use
                             child: RaisedButton(
                               onPressed:() async{
                                 if(_formkey.currentState.validate()){
                                   await _loginInWhitEmailPassword();
                                 }
                               },
                               splashColor: Colors.transparent,
                               elevation: 50,
                               highlightElevation: 30,
                               color:  Colors.redAccent,
                               shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(15))),
                               child :
                               Text('Se connecter', style:
                               TextStyle(
                                 fontSize: 20,
                                 color: Colors.white,
                                 fontWeight: FontWeight.bold,
                               ),

                               ),
                             ),
                           ),
                         ),
                         SizedBox(height: 50,),
                         Row(
                           mainAxisAlignment: MainAxisAlignment.center,
                           children: <Widget>[
                             buttonMedia(
                               press: () {
                                 signInWithGoogle().then(
                                       (value) => {
                                     this.user = user,
                                     Navigator.push(
                                    (context),
                                    MaterialPageRoute(
                                   builder: (context) {
                                   return PIZZA();
                                                     },
                                     ),
                                     )
                                   },
                                 );
                               },
                             ),
                             Padding(
                               padding: const EdgeInsets.symmetric(horizontal: 25),
                               child: buttonMediafacebook(
                                 press: () {
                                   signInWhitFacebook().then(
                                         (value) => {
                                       this.user = user,
                                       Navigator.of(context).pushNamed('/pizza'),
                                     },
                                   );
                                 },
                               ),
                             )
                           ],
                         ),
                         Padding(
                           padding: const EdgeInsets.symmetric(vertical: 15),
                           child: Row(
                             mainAxisAlignment: MainAxisAlignment.center,
                             children: <Widget>[
                               Text("Vous n'avez pas de compte ? ",style: TextStyle(fontSize: 20,fontWeight: FontWeight.w400,color: Colors.white),),
                               GestureDetector(
                                   onTap: (){ Navigator.of(context).pushNamed('/sign');},
                                   child:
                                   Text("S'inscrire",style: TextStyle(fontSize: 20,color:  Colors.redAccent, decoration: TextDecoration.underline,),))
                             ],
                           ),
                         ),

                       ],
                     ),
                   ),
                 ],
               ),
             ),
           ),
         )
       ],
     );
  }
   Future<void> _loginInWhitEmailPassword() async{
    try {
      final user = (await _auth.signInWithEmailAndPassword(email: _emailController.text, password: _passwordController.text))
          .user;
           if(!user.isEmailVerified)
             {
               await user.sendEmailVerification();
             }
          Navigator.of(context).pushReplacement(MaterialPageRoute(builder:(_)=>PIZZA()));

    } catch(e){
      // ignore: deprecated_member_use
      _scaffoldKey.currentState.showSnackBar(SnackBar(content: Text("Failed to sign in email and password")));
      print(e.toString());
    }
  }
}

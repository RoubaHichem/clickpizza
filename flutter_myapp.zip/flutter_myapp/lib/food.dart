import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import 'buy.dart';

class FOODS extends StatefulWidget {
  @override
  _FOODSState createState() => _FOODSState();
}

class _FOODSState extends State<FOODS> {
  FirebaseUser user;


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:Colors.white,
        body: StreamBuilder(
            stream: Firestore.instance.collection("foods").snapshots(),
            builder: (BuildContext , AsyncSnapshot<QuerySnapshot> snapshot){
              if(!snapshot.hasData){return Text('Loading');}
              int lenght = snapshot.data.documents.length;
              return ListView.builder(
                scrollDirection: Axis.horizontal,
                  itemCount: lenght,
                  itemBuilder: (_,index){
                    final DocumentSnapshot doc = snapshot.data.documents[index];
                    return Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      child: Card(
                        shadowColor: Colors.red,
                        elevation: 10,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(50)
                        ),
                        child: Container(
                          width: 250,
                          child: Container(
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(50),
                                gradient: LinearGradient(
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                  stops: [0.75,0.2],
                                  colors: [Colors.red,Colors.amberAccent]
                                )
                            ),
                            child: Column(
                              children: <Widget>[
                                Padding(
                                  padding: const EdgeInsets.symmetric(vertical: 20),
                                  child: Container(
                                      height: 170,
                                      child: Image.network(doc.data['image'])),
                                ),
                                Padding(
                                  padding: const EdgeInsets.symmetric(vertical: 10),
                                  child: Text(doc.data['nom'],style: TextStyle(fontSize: 25,color: Colors.white),),
                                ),
                                ListTile(
                                  subtitle: Text(doc.data['ingrediants'],style: TextStyle(color: Colors.white,fontSize: 18,fontWeight: FontWeight.w400),),
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Text(doc.data['prix']+'Da',style: TextStyle(fontSize: 20,color: Colors.white),),
                                ),

                                InkWell(
                                onTap: (){
                                  Scaffold.of(context).showSnackBar(SnackBar(content: Text("Une pizza achetée")));
                                  print(doc.data['nom']);
                                  Firestore.instance
                                      .collection('panier')
                                      .add({'Nom':doc.data['nom'],'Prix':doc.data['prix']})
                                      .catchError((e){
                                    print(e);
                                  });},
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(vertical: 40),
                                  child: Icon(FontAwesomeIcons.shoppingBasket,color: Colors.black87,),
                                ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    );
                  }
              );
            }
        )
    );
  }

}

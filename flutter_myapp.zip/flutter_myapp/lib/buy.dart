

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_myapp/pizza.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'Bottomappbar.dart';



class BUY extends StatefulWidget {


  @override
  _PROFILEState createState() => _PROFILEState();
}

class _PROFILEState extends State<BUY> {
  String price='';
  String prix;
  int somme=0;
  bool chekboxvalue = false;
   @override
  Widget build(BuildContext context) {
   
    return Scaffold(
      body: Stack(
           children: [
             Stack(
               children: [
                 Positioned(
                     left: 330,
                     top: 80,
                     child: Container(
                       height: 65,
                       width: 70,
                       decoration: BoxDecoration(
                         color: Color(0xffFF7B54),
                         borderRadius: BorderRadius.circular(10),
                       ),
                       child: Icon(FontAwesomeIcons.shoppingCart,color: Colors.white,),
                     ),),
                 Positioned(
                   left: 20,
                   top: 80,
                   child: Container(
                     height: 65,
                     width: 70,
                     decoration: BoxDecoration(
                       color: Color(0xffFF7B54),
                       borderRadius: BorderRadius.circular(10),
                     ),
                     child: IconButton(
                       icon: Icon(FontAwesomeIcons.angleLeft,color: Colors.white,),
                       onPressed: (){
                         Navigator.of(context).push(MaterialPageRoute(builder:(context)=>PIZZA()));
                       },
                     )
                   ),),
                 Positioned(
                   left: 145,
                   top: 100,
                   child: Text("Mon Panier",style: TextStyle(fontSize: 25,fontWeight: FontWeight.bold),)
                   ),
                 Padding(
                   padding: const EdgeInsets.symmetric(vertical: 140),
                   child: Container(
                     child: StreamBuilder(
                       stream: Firestore.instance.collection("panier").snapshots(),
                       builder: (BuildContext,AsyncSnapshot<QuerySnapshot> snapshot){
                         if(!snapshot.hasData){return Text('Loading');}
                         int lenght = snapshot.data.documents.length;
                         somme =0;
                         return ListView.builder(
                             scrollDirection: Axis.vertical,
                             itemCount: lenght,
                             itemBuilder: (_,index){
                               final DocumentSnapshot doc = snapshot.data.documents[index];
                               somme=somme+ int.parse(doc.data['Prix']);
                               return Padding(
                                 padding: const EdgeInsets.symmetric(vertical:4,horizontal: 10),
                                 child:Container(
                                   color: Colors.white54,
                                   height: 100,
                                   child: Padding(
                                       padding: const EdgeInsets.symmetric(vertical: 10),
                                       child: Stack(
                                         children: [
                                           Positioned(
                                             child:  Padding(
                                               padding: const EdgeInsets.symmetric(vertical: 15,horizontal: 10),
                                               child: Text(doc.data['Nom'],style: TextStyle(fontWeight: FontWeight.bold,fontSize: 18),),
                                             ),),
                                           Positioned(
                                             child:  Padding(
                                               padding: const EdgeInsets.symmetric(vertical: 15,horizontal: 10),
                                               child: Text("\n"+doc.data['Prix']+' Da',style: TextStyle(fontWeight: FontWeight.w600,fontSize: 18,color: Color(0xffFF7B54), ),),
                                             ),),

                                           Positioned(
                                               left: 350,
                                               child:IconButton(
                                                 icon: Icon(FontAwesomeIcons.trash,color: Colors.red,),
                                                 onPressed: (){
                                                   snapshot.data.documents[index]
                                                       .reference
                                                       .delete();
                                                 },
                                               )
                                           ),

                                         ],
                                       )
                                   ),
                                 )

                               );
                             }
                         );
                       }
                   ),
                   ),
                 ),
                 Positioned(
                     left: 45,
                     top: 620,
                     child:Container(
                       child: Text('$price',style: TextStyle(fontSize: 20,color: Colors.black54,fontWeight: FontWeight.bold),),
                     )),
                 Positioned(
                     left: 180,
                     top: 625,
                     child:Container(
                       child: Text("Service Livraison + 100 Da",style: TextStyle(fontSize: 15,color: Colors.black54,fontWeight: FontWeight.bold),),
                     )),
                 Positioned(
                     left: 350,
                     top: 610,
                     child:Checkbox(
                       value: chekboxvalue,
                       onChanged: (bool value){
                         setState(() {
                           chekboxvalue=value;
                         });
                       },
                       activeColor: Color(0xffFF7B54),
                     )),
                 Positioned(
                   left: 45,
                   top: 660,
                   child: Container(
                     child: SizedBox(
                       width: 350,
                       height: 55 ,
                       // ignore: deprecated_member_use
                       child: RaisedButton(
                         onPressed:()=>changetext(),
                         splashColor: Colors.transparent,
                         highlightElevation: 20,
                         color: Color(0xffFF7B54),
                         shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(10))),
                         child :
                         Text('Valider', style:
                         TextStyle(
                           fontSize: 25,
                           color: Colors.white,
                           fontWeight: FontWeight.bold,
                           fontFamily: 'Montserrat',
                         ),

                         ),
                       ),
                     ),
                   ),
                 ),

               ],
             )
           ],
         ),
      bottomNavigationBar: BottomBar(),
      );
  }

changetext(){
     setState(() {
        price ='$somme'+' Da';
     });
}


}

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_myapp/boissons.dart';
import 'Bottomappbar.dart';
import 'food.dart';

class PIZZA  extends StatefulWidget {

  @override
  _PIZZAState createState() => _PIZZAState();
}

class _PIZZAState extends State<PIZZA > {
  @override
  Widget build(BuildContext context) {


    return MaterialApp(
      home: Scaffold(
        body: Center(
          child: ListView(
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Container(
                  child : Row(
                    children: <Widget>[
                      Column(
                        children: <Widget>[
                          SizedBox(height: 50,),
                          Text(
                            'OneClick\nPizza',
                            style: TextStyle(
                              fontSize: 50,
                              color: Colors.black87,
                              letterSpacing: -1,
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              ),
              Container(
                height: 550,
                width: double.infinity,
                child: DefaultTabController(
                  length: 2,
                  child: Scaffold(
                    appBar: AppBar(
                      elevation: 0.0,
                      backgroundColor: Colors.white,
                      bottom: PreferredSize(
                        preferredSize: Size.fromHeight(5),
                        child: Container(
                          color: Colors.transparent,
                          child: SafeArea(
                            child: Column(
                              children: <Widget>[
                                TabBar(
                                  isScrollable: true,
                                  labelPadding: EdgeInsets.only(top: 10),
                                  indicatorColor: Colors.transparent,
                                  labelColor: Colors.black,
                                  tabs: <Widget>[
                                    Container(
                                      padding: EdgeInsets.symmetric(horizontal: 30),
                                      child: Text('Pizza',style: TextStyle(
                                        fontSize: 25,color: Colors.black
                                      ),),
                                    ),
                                    Container(
                                      padding: EdgeInsets.symmetric(horizontal: 30),
                                      child: Text('Boissons',style: TextStyle(
                                        fontSize: 25,
                                      ),),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                      body: TabBarView(
                        children: <Widget>[
                          FOODS(),
                          Boissons(),
                        ],
                      ),
                  ),
                ),
              ),
            ],
          ),
        ),
        bottomNavigationBar: BottomBar(),
      ),
      );
  }
}

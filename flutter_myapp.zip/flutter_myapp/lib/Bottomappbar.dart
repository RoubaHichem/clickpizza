
import 'package:flutter/material.dart';
import 'package:flutter_myapp/buy.dart';
import 'package:flutter_myapp/pizza.dart';
import 'Profile.dart';
import 'package:maps_launcher/maps_launcher.dart';


class BottomBar extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 70,
      child: BottomAppBar(
         color: Colors.white,
         elevation: 0.0,
        child: Padding(
          padding: EdgeInsets.symmetric(vertical: 4),
           child: Row(
             mainAxisAlignment: MainAxisAlignment.spaceEvenly,
             children: <Widget>[
               GestureDetector(
                 onTap: (){
                   Navigator.of(context).push(MaterialPageRoute(builder:(context)=>PIZZA()));
                 },
                 child:Container(
                     height: 50,
                     width: 30,
                     child: Image.asset(
                       "images/home.png",
                       fit: BoxFit.contain,
                       color: Colors.black87,
                     )
                 ),
               ),
               GestureDetector(
                 onTap: (){
                   Navigator.of(context).push(MaterialPageRoute(builder:(context)=>PROFILE()));
                 },
                 child:Container(
                     height: 50,
                     width: 30,
                     child: Image.asset(
                      "images/user.png",
                       fit : BoxFit.contain,
                       color: Colors.black87,
                     ),
                 ),
               ),
               GestureDetector(
                 onTap: (){
                   Navigator.of(context).push(MaterialPageRoute(builder:(context)=>BUY()));
                 },
                 child:Container(
                   height: 50,
                   width: 30,
                   child: Image.asset(
                     "images/buy.png",
                     fit :BoxFit.contain,
                     color: Colors.black87,
                   ),
                 ),
               ),
               GestureDetector(
                 onTap: (){
                   MapsLauncher.launchQuery("111 Restaurant - oran");
                 },
                 child:Container(
                   height: 50,
                   width: 30,
                   child: Image.asset(
                     "images/map.png",
                     fit :BoxFit.contain,
                     color: Colors.red,
                   ),
                 ),
               ),
             ],
           ),
        ),
      ),
    );
  }

}

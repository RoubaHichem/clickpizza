

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class Boissons extends StatefulWidget {
  @override
  _HotelsState createState() => _HotelsState();
}

class _HotelsState extends State<Boissons> {
  FirebaseUser user;
  String Nom;
  String PRIX;
  @override

  Widget build(BuildContext context) {
    return Scaffold(

        body: StreamBuilder(
            stream: Firestore.instance.collection("boissons").snapshots(),
            builder: (BuildContext , AsyncSnapshot<QuerySnapshot> snapshot){
              if(!snapshot.hasData){return Text('Loading');}
              int lenght = snapshot.data.documents.length;
              return ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: lenght,
                  itemBuilder: (context,index){
                    final DocumentSnapshot doc = snapshot.data.documents[index];
                    return Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      child: Container(
                        width: 250,
                        child:Card(
                          shadowColor: Colors.redAccent,
                          elevation: 10,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(50)
                          ),
                          child:  Container(
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(50),
                                gradient: LinearGradient(
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                    stops: [0.72,0.2],
                                    colors: [Color(0xffCF3030),Color(0xffDDDDDD)]
                                )
                            ),
                            child: Column(
                              children: <Widget>[
                                Padding(
                                  padding: const EdgeInsets.symmetric(vertical: 20),
                                  child: Container(
                                      height: 200,
                                      child: Image.network(doc.data['image'])),
                                ),
                                Padding(
                                  padding: const EdgeInsets.symmetric(vertical: 20),
                                  child: Text(doc.data['nom'],style: TextStyle(fontSize: 30,color: Colors.white),),
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(10),
                                  child: Text(doc.data['prix']+' Da',style: TextStyle(fontSize: 20,color:Color(0xffE8DED2)),),
                                ),
                                InkWell(
                                  onTap: (){
                                    Scaffold.of(context).showSnackBar(SnackBar(content: Text("Une boisson achetée")));
                                    Firestore.instance
                                        .collection('panier')
                                        .add({'Nom':doc.data['nom'],'Prix':doc.data['prix']})
                                        .catchError((e){
                                      print(e);
                                    });
                                    },
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(vertical: 45),
                                    child: Icon(FontAwesomeIcons.shoppingBasket,color: Colors.black87,),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    );
                  }
              );

            }
        )
    );
  }


}
